#include "MyGame.h"
#include "SDL_ttf.h"
#include <SDL.h>
#include <SDL_image.h>
#include<iostream>
#include<string>



void MyGame::init_audio() {
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 1024) == -1) {
        printf("Mix_OpenAudio: %s\n", Mix_GetError());
        return;
    }

    sound = Mix_LoadWAV("drop.wav");
    if (sound == nullptr) {
        printf("Mix_LoadWAV: %s\n", Mix_GetError());
    }

    goal = Mix_LoadWAV("goal.wav");
    if (goal == nullptr) {
        printf("Mix_LoadWAV: %s\n", Mix_GetError());
    }
    else {
        std::cout << "Sound effect loaded" << std::endl;
    }
}


void MyGame::init(SDL_Renderer* renderer) {
    SDL_Surface* surface = IMG_Load("bat.png");

    if (surface != nullptr) {
        std::cout << "Loaded" << std::endl;
    }
    else {
        std::cout << "Not Loaded" << std::endl;
    }

    bat1 = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_FreeSurface(surface);


    SDL_Surface* surface2 = IMG_Load("ball.png");


    if (surface2 != nullptr) {
        std::cout << "Loaded" << std::endl;
    }
    else {
        std::cout << "Not Loaded" << std::endl;
    }

    ball1 = SDL_CreateTextureFromSurface(renderer, surface2);
    SDL_FreeSurface(surface2);

   




}




void MyGame::on_receive(std::string cmd, std::vector<std::string>& args) {
    if (cmd == "GAME_DATA") {
        if (args.size() == 4) {
            game_data.player1Y = stoi(args.at(0));
            game_data.player2Y = stoi(args.at(1));
            game_data.ballX = stoi(args.at(2));
            game_data.ballY = stoi(args.at(3));
        }
    }

  else {
        std::cout << "Received: " << cmd << std::endl;
        
        if (cmd == "SCORES") {

            if (args.size() == 2) {
                  
                game_data.player1score = stoi(args.at(0));
                game_data.player2score = stoi(args.at(1));

                std::cout << "Player1: ";
                std::cout << game_data.player1score << std::endl;

                std::cout << "Player2: ";
                std::cout << game_data.player2score << std::endl;
            
                play_goal();
            }

        }

        if (cmd == "BALL_HIT_BAT1") {
        
        
            play_sound();
        }

        if (cmd == "BALL_HIT_BAT2") {


            play_sound();
        }
            

        if (cmd == "HIT_WALL_DOWN") {
            play_sound();
        }

        if (cmd == "HIT_WALL_UP") {
            play_sound();
        }
      
}
}

void MyGame::send(std::string message) {
    messages.push_back(message);
}

void MyGame::input(SDL_Event& event) {
    switch (event.key.keysym.sym) {
    case SDLK_w:
        send(event.type == SDL_KEYDOWN ? "W_DOWN" : "W_UP");
        break;
    case SDLK_f:
        send(event.type == SDL_KEYDOWN ? "F_DOWN" : "F_UP");
        break;
    }

    switch (event.key.keysym.sym) {
    case SDLK_s:
        send(event.type == SDL_KEYDOWN ? "S_DOWN" : "S_UP");
        break;
    case SDLK_f:
        break;
    }

 
}

void MyGame::play_sound() {
    if (Mix_PlayChannel(-1, sound, 0) == -1) {
        printf("Error playing sound. Mix_PlayChannel: %s\n", Mix_GetError());

    }

}

void MyGame::play_goal() {
    if (Mix_PlayChannel(-1, goal, 0) == -1) {
        printf("Error playing goal. Mix_PlayChannel: %s\n", Mix_GetError());

    }

}

void MyGame::update() {
   player1.y = game_data.player1Y;
   ball.y = game_data.ballY;
   ball.x = game_data.ballX;
   player2.y = game_data.player2Y;
   player2.y = game_data.player2Y;
}

void MyGame::render(SDL_Renderer* renderer) {
    SDL_RenderCopy(renderer, bat1, NULL, &player1 );
    SDL_RenderCopy(renderer, bat1, NULL, &player2);
    SDL_RenderCopy(renderer, ball1, NULL, &ball);
    SDL_RenderCopy(renderer, textTexture2, NULL, &textRect2);
    SDL_RenderCopy(renderer, textTexture, NULL, &textRect);



  std::string str = std::to_string(game_data.player1score);
  const char* c = str.c_str();
  TTF_Init();
  TTF_Font* font = TTF_OpenFont("OpenSans-Bold.ttf", 32);
  SDL_Surface* textSurf = TTF_RenderText_Solid(font, c, { 255,255,255 });
  textTexture = SDL_CreateTextureFromSurface(renderer, textSurf);
  SDL_FreeSurface(textSurf);
  TTF_CloseFont(font);





  std::string str2 = std::to_string(game_data.player2score);
  const char* d = str2.c_str();
  TTF_Init();
  TTF_Font* font2 = TTF_OpenFont("OpenSans-Bold.ttf", 32);
  SDL_Surface* textSurf2 = TTF_RenderText_Solid(font2, d, { 255,255,255 });
  textTexture2 = SDL_CreateTextureFromSurface(renderer, textSurf2);
  SDL_FreeSurface(textSurf2);
  TTF_CloseFont(font2);



  SDL_SetRenderDrawColor(renderer, 122, 255, 244, 255);
}


void MyGame::destroy() {

    Mix_FreeChunk(sound);

    sound = nullptr;

    Mix_CloseAudio();

    Mix_FreeChunk(goal);

    goal = nullptr;

    Mix_CloseAudio();

}

