#ifndef __MY_GAME_H__
#define __MY_GAME_H__

#include <iostream>
#include <vector>
#include <string>

#include "SDL.h"
#include "SDL_image.h"
#include "SDL_mixer.h"

static struct GameData {
    int player1Y = 0;
    int player2Y = 0;
    int ballX = 0;
    int ballY = 0;
    int player1score = 0;
    int player2score = 0;

} game_data;

class MyGame {

private:
    SDL_Rect player1 = { 200, 0, 20, 60 };
    SDL_Rect player2 = { 580, 30, 20, 60 };
    SDL_Rect ball = { 200, 0, 10, 10 };
    SDL_Rect textRect = { 100, 0, 50, 50 };
    SDL_Rect textRect2 = { 600, 0, 50, 50 };

    SDL_Texture* bat1;
    SDL_Texture* ball1;    
    SDL_Texture* textTexture;
    SDL_Texture* textTexture2;


    Mix_Chunk* sound;
    Mix_Chunk* goal;

public:
    std::vector<std::string> messages;

    void init(SDL_Renderer* renderer);

    void on_receive(std::string message, std::vector<std::string>& args);
    void send(std::string message);
    void input(SDL_Event& event);
    void update();
    void render(SDL_Renderer* renderer);




    void init_audio();
    void play_sound();
    void play_goal();
    void destroy();
};

#endif